<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'test' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'root' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'kTzm3@s>4D`u|p{AfIfe|7Juo94up:<hQS9%,>W~Jv? IgIf0E.elEp*bD@=3ZeB' );
define( 'SECURE_AUTH_KEY',  'p(XPKPUU1fJP0G~JOe0^k] M%.7)MOauxAcTy/f^uw&h=Z6BzYKKIw 62%>>R5g6' );
define( 'LOGGED_IN_KEY',    '9<7x+SG*)Cl.4by~$JhXnXd$m*K}TJ,L-Ud$DaY||IM wM9QL8r$`4V6])Y[7jud' );
define( 'NONCE_KEY',        '8/w>hZLuO$i<B.Y,Rn+7MzG`Fz@LU{2xAnU>SP!<uju,hN}+ntw2Q p*klsOfGuM' );
define( 'AUTH_SALT',        'BnI#3zPwfbEF[,mzRac;+&Cg5oPjF<=j:oPlbo#TJ:_tZIXS4ex:n2et5|b;R}VA' );
define( 'SECURE_AUTH_SALT', 'b7$5IOIk#|d}-.na@kG<<C`c.~LCeES6LVP]tg|2G<t4SIpSFVM&E/bM6:;4c0Cc' );
define( 'LOGGED_IN_SALT',   'BrcO7A6unxwosnobt:g|3fmZ;v5/37qbCuVI1hK&dDlRZ(`PM~~:GAq1n|PujtsK' );
define( 'NONCE_SALT',       ')YJ2G9t^RVpU6kS%SuuJju{<]km:_|LB2/PO9Bzzj]Lq77nffe7MM^t2]`db(Jpv' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
